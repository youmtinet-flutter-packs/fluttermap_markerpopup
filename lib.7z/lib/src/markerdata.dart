import 'package:flutter_map/flutter_map.dart';

abstract class MarkerData {
  Marker marker;
  MarkerData({required this.marker});
}
